# MyLight
An Android app controling a usb light
